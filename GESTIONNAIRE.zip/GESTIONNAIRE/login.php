<?php
 session_start();
//Page de vérification du login

 //connexion à la base de donnee.
 require 'base de donnee\BDD.php';

$admin = htmlspecialchars($_POST['nom_utilisateur']);
$password = htmlspecialchars($_POST['password']); 


    $prendre = $bdd->query("SELECT * FROM administrateur WHERE nom_utilisateur = '$admin'");
    $lire = $prendre->fetch();
    //verification du password
   $passe = password_verify($password,$lire['mot_de_passe']);
    
    
    if($prendre && $passe) {
        //en cas de login exact

        $_SESSION['nom_admin'] = $lire['nom'];
        $_SESSION['prenom_admin'] = $lire['prenom'];
     
        header('Location:plateform\vente\vente.php');
        
    }else {

        //en cas de login erroné
        echo "<script>
        alert('désolé le nom d\'utilisateur "." "."ou le mot de passe est incorrect')</script>
        <meta http-equiv=\"refresh\" content=\"0;URL=index.php\">";
    }

?>
