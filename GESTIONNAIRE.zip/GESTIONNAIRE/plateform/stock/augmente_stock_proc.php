<?php


//connection à la base de donnée
 require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';

    //recuperation de l'identifiant
if(isset($_GET['id_article'])){
    $id_article = $_GET['id_article'];
}
//recuperation de la nouvelle quantité
$quantite = $_POST['quantite'];

//verification le nombre est positif
if($quantite < 0){
    echo "<script>
        alert('veillez entrer"." "."un nombre positif')</script>
        <meta http-equiv=\"refresh\" content=\"0;URL= affiche_stock.php?id_article=$id_article\">";
}else{

//requete pour interroger la BD
$prendre = $bdd->query("SELECT * FROM article WHERE id_article='$id_article' ");

$lire = $prendre->fetch();

//processus d'augmentation
$update = $bdd->prepare('UPDATE article SET  quantite = :quantite WHERE id_article = :id_article');

$update->execute(array(
                       'quantite' => $quantite,
                      'id_article' => $id_article));

//alert de confirmation
    if($update){
        echo "<script>
        alert('Augmentation "." "."effectuée avec succès')</script>
        <meta http-equiv=\"refresh\" content=\"0;URL= affiche_stock.php\">";
    }
}
?>
