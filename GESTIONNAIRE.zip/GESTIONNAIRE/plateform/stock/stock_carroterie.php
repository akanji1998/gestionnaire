<?php
session_start();
//connexion à la base de donnee.
require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';

?>
<html>
    <head>
        <meta charset="utf-8">
        <title>Cosmos Quincaillerie - Mon Stock</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <!--Style css-->
        <link rel="stylesheet" href="Sans%20titre-1.css" type="text/css">
        
        <style>
            /*LOGO*/
            .log {
                font-size: 30px;
                text-decoration: none;
                color: #fff;
               padding-left: 15px;
                position: relative;
                bottom: 10px;
            }
            .log span {
                color: #f4c613;
                font-size: 20px;
                position: relative;
                top: 17px;
                right: 70px;
            }
            .log:hover{
                text-decoration: none;
                color: #fff;
            }
            .admin h6 {
                color: #fff;
                margin: 0;
                margin-top: 10px;
            }
            .admin a {
                padding: 0;
                color: blue;
            }
            
        </style>
    </head>
    <body>
       
       <!--HEARDER ET NAVIGATION-->
        <div class="bg-dark fixed-top">
            <div class="container-fluid">
                <div class="row">            
                    <nav class="col navbar navbar-expand  bg-dark navbar-dark ">
                       
                        <a class="log navbar-brand" href="../vente/vente.php">
                            Cosmos <span>Quincaillerie</span>
                        </a>

                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="../vente/vente.php">Acceuil</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../client/affichage_client/affiche_client.php">Mes clients</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../enregistrement_article/affichage_articles/afficher_article.php">Mes articles</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../stock/affiche_stock.php">Mon stock</a>
                            </li>
                        </ul>
                        
                    </nav>
                    <div class="admin col-4 text-right">
                        <h6><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></h6>
                        <a href="#" class="btn">Déconnexion</a>
                    </div> 
                </div>
                
            </div>
            <div class="container-fluid">
               <div class="row">
                    <nav class="col navbar navbar-expand  bg-light navbar-light ">
                       
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="affiche_stock.php">Electricité</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="stock_plomberie.php">Plomberie</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="stock_sanitaire.php">Sanitaire</a>
                            </li>
                            <li class="nav-item active bg-dark">
                                <a class="nav-link" href="stock_carroterie.php">Carrotérie</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="stock_peinture.php">Peinture</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="stock_autres.php">Autres</a>
                            </li>
                        </ul>
                        
                    </nav>
                </div>
            </div>
        </div>
       <!--<header>
             
              <div class="logo">
                  <h1><em>Cosmos</em></h1>
                  <h3>Quincaillerie</h3>
              </div>

               <div class="navigation">
                  <h3>Administrateur:<span><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></span></h3>
                   <nav>
                        <ul>
                            <li><a href="..\Menu\menu.php">retour au menu</a></li>
                           
                        </ul>
                    </nav>
               </div>
               
         </header>-->
       
       
       
        <div id="conteneur">
           
           <!--AFFICHAGE D'APPROVISIONNEMENT-->
           <?php
             if(isset($_GET['id_article'])){
                 $id_article = $_GET['id_article'];
                 $prendre = $bdd->query("SELECT quantite,designation FROM article WHERE id_article = '$id_article' ");
                 $lire = $prendre->fetch();
                 
            ?>
            
            <div class="approvisionner">
                <form method="post" action="augmente_stock_proc.php?id_article=<?php echo $id_article?>">
                   <h1><?php echo $lire['designation']; ?></h1>
                    <label>Quantité: </label><br>
                    <input type="number" name="quantite"  value="<?php echo $lire['quantite']; ?>"><br>
                    <input type="submit"  value="OK"  id="submit">
                </form>
            </div>
            
            <?php
                                           }  
            ?>
            
            <h1>mon stock</h1>
               
            <!--stock carroterie-->
          
              
               <!--nombre d'article de carroterie-->
               <?php $prendre_quantite_carroterie= $bdd->query("SELECT SUM(quantite) AS quantite_total FROM article WHERE categorie = 'carroterie'");
                $lire_quantite_carroterie = $prendre_quantite_carroterie->fetch();
                ?>

                <h2>carroterie<span>(<?php echo $lire_quantite_carroterie['quantite_total'];?> articles)</span></h2>
                
                    <!--recuperation article--->
                    <?php $prendre_carroterie= $bdd->query("SELECT id_article, designation, sous_categorie, quantite FROM article WHERE categorie = 'carroterie' "); ?>
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                       <thead>
                            <tr>
                                <th>Identifiant</th>
                                <th>Désignation</th>
                                <th>sous_catégorie</th>
                                <th>Quantité</th>
                                <th>Approvisionnement</th>
                            </tr>
                        </thead>
                        <?php while($lire_carroterie = $prendre_carroterie->fetch()){?>
                        <tbody>
                            <tr>
                                <td><?php echo $lire_carroterie['id_article']; ?></td>                       
                                <td class="designation"><?php echo $lire_carroterie['designation']; ?></td>
                                <td><?php echo $lire_carroterie['sous_categorie']; ?></td>
                                <td><?php echo $lire_carroterie['quantite']; ?></td>
                                <td><button id="button"><a href="affiche_stock.php?id_article=<?php echo $lire_carroterie['id_article']; ?>">augmenter</a></button></td>
                            </tr>
                        </tbody>
                        <?php }
                        $prendre_carroterie->closeCursor();
                        ?>
                    </table>
             
            
            
         
        </div>
        
        <script src="../../js/jquery-3.5.1.js"></script>
        <script src="../../js/jquery.dataTables.min.js"></script>
        <script src="../../js/dataTables.bootstrap4.min.js"></script>
        <script>
            $(document).ready(function(){
                $('#example').DataTable();
            });
            
        </script>
    </body>
</html>
