<!--Enregistrement des DEVIS-->
<?php


require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';

    //recuperation des info du DEVIS
    $id_client = $_POST['client'];
    $quantite = $_POST['quantite'];
    $id_article = $_POST['vente'];
    $date_devis = $_POST['date_devis'];
   
   
   

foreach($_POST['quantite'] as $quantite ){

  if(!empty($quantite) and $quantite>0){
      
      
     
        if(isset($_POST['vente'])){
           
           
            foreach($_POST['vente'] as $id_article) {
                
                
              
                //recuperation des article concernés par le devis
                $prendre = $bdd->query("SELECT * FROM article WHERE id_article = '$id_article' ");
                $lire = $prendre->fetch();
                
                
                
                    //recuperation des articles
                    $designation = $lire['designation'];
                    $prix_unitaire = $lire['prix_unitaire'];
                    $total = $lire['prix_unitaire']*$quantite;


                    //recuperation des informtions du client
                    $prendre_client = $bdd->query("SELECT * FROM client WHERE numero_client = '$id_client' ");
                    $lire_client = $prendre_client->fetch();

                    if(isset($id_client)){

                        $tel_client = $id_client;
                        $nom_client = $lire_client['nom'];
                        $prenom_client = $lire_client['prenom'];

                        //enregistrement du devis dans la table DEVIS
                        $inserer_achat = $bdd->query("INSERT INTO devis (nom_client,prenom_client,tel_client,article_devis,prix_unitaire,quantite,total,date_devis) VALUES ('$nom_client', '$prenom_client', '$tel_client', '$designation', '$prix_unitaire', '$quantite', '$total','$date_devis') ");

                        if($inserer_achat){
                            
                            header('Location: devis.php');
                        }


                    } else 
                    echo "<script>
                    alert('veuillez selectionner "." "."un client')</script>
                    <meta http-equiv=\"refresh\" content=\"0;URL=devis.php\">";
                    
                
             
            }
            
        }else
        echo "<script>
        alert('veuillez selectionner "." "."au moins un articles')</script>
        <meta http-equiv=\"refresh\" content=\"0;URL=devis.php\">";
     
      
            
    } else
    echo "<script>
    alert('veuillez entrer "." "."la quantite des articles')</script>
    <meta http-equiv=\"refresh\" content=\"0;URL=devis.php\">";
    
} 


?>