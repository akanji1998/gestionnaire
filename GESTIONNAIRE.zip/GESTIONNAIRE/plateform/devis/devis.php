<?php
session_start();
//connexion à la base de donnee.
require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';

//prendre article dans la BDD
$prendre = $bdd->query("SELECT * FROM article");
//prendre client dans la BDD
$prendre_client = $bdd->query("SELECT * FROM client");

?>
   

<html>
    <head>
        <meta charset="utf-8">
        <title>Vente</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <!--Style css-->
        <link type="text/css" rel="stylesheet" href="devis.css">
        <style>
            /*LOGO*/
            .log {
                font-size: 30px;
                text-decoration: none;
                color: #fff;
               padding-left: 15px;
                position: relative;
                bottom: 10px;
            }
            .log span {
                color: #f4c613;
                font-size: 20px;
                position: relative;
                top: 17px;
                right: 70px;
            }
            .log:hover{
                text-decoration: none;
                color: #fff;
            }
            .admin h6 {
                color: #fff;
                margin: 0;
                margin-top: 10px;
            }
            .admin a {
                padding: 0;
                color: blue;
            }
            
            
            
        </style>
    </head>
    <body>
       <!--HEARDER ET NAVIGATION-->
        <div class="bg-dark fixed-top">
            <div class="container-fluid">
                <div class="row">            
                    <nav class="col navbar navbar-expand  bg-dark navbar-dark ">
                       
                        <a class="log navbar-brand" href="../vente/vente.php">
                            Cosmos <span>Quincaillerie</span>
                        </a>

                        <ul class="navbar-nav">
                            <li class="nav-item active">
                                <a class="nav-link" href="../vente/vente.php">Acceuil</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../client/affichage_client/affiche_client.php">Mes clients</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../enregistrement_article/affichage_articles/afficher_article.php">Mes articles</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../stock/affiche_stock.php">Mon stock</a>
                            </li>
                        </ul>
                        
                    </nav>
                    <div class="admin col-4 text-right">
                        <h6><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></h6>
                        <a href="#" class="btn">Déconnexion</a>
                    </div> 
                </div>
                
            </div>
            <div class="container-fluid">
               <div class="row">
                    <nav class="col navbar navbar-expand  bg-light navbar-light ">
                       
                        <ul class="navbar-nav">
                            <li class="nav-item ">
                                <a class="nav-link" href="../vente/vente.php">Achat</a>
                            </li>
                            <li class="nav-item active bg-dark">
                                <a class="nav-link" href="devis.php">Dévis</a>
                            </li>
                            
                        </ul>
                        
                    </nav>
                </div>
            </div>
        </div>
       <!--<header>
         
          <div class="logo">
              <h1><em>Cosmos</em></h1>
              <h3>Quincaillerie</h3>
          </div>

           <div class="navigation">
              <h3>Administrateur:<span><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></span></h3>
               <nav>
                    <ul>
                        <li><a href="..\Menu\menu.php">retour au menu</a></li>
                    </ul>
                </nav>
           </div>
         
        </header>-->
       
        <div id="conteneur">
          
           
           <form method="post" action="devis_proc.php">
                
                <div class="parametre">
                 
                  <label>Quantité :</label>
                 <input type="number" name="quantite[]" value="" required>
                 
                 <label>Date :</label>
                 <input type="date" name="date_devis" required>
                 
                 <label>Client :</label>
                    <select name="client" required>
                      <!--affichage des client-->
                       <option></option>
                       <?php while($lire_client=$prendre_client->fetch()){?>
                            
                            <option value="<?php echo $lire_client['numero_client']; ?>" title="<?php echo $lire_client['nom'].' '.$lire_client['prenom']; ?>"> <?php echo $lire_client['numero_client']; ?> </option>
                         
                        <?php } ?>
                    </select>
                    <br>
                    <input type="submit"  value="ajouter à mon devis" class="btn">
                    <a href="afficher_devis/afficher_devis.php">afficher mes Devis</a>
                    
                </div>
             
                
             <?php while($lire = $prendre->fetch()){ ?>
                <div class="article">
                   <div class="photo"></div>
                    <h2><?php echo $lire['designation']; ?></h2>
                    <h3>prix : <?php echo $lire['prix_unitaire']; ?>F cfa</h3>
                    <h4>Description :</h4>
                    <div class="description">
                         <p><?php echo $lire['description']; ?></p>
                    </div>
                    
                   <div class="achat">
                        <input type="checkbox" name="vente[]"  value="<?php echo $lire['id_article'];?>">
                        <a href="javascript:coche();">achète</a>
                    </div>
                    
                    
                </div>
             <?php } ?>
            </form>
            
        </div>
        
        
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    </body>
</html>