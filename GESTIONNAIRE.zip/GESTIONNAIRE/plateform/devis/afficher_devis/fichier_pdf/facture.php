<?php

require('mysql_table.php');
require('C:/wamp64/www/GESTIONNAIRE/base de donnee/BDD.php');

//recuperation de la date et client;
$id_client = $_GET['id_client'];
$date_devis = $_GET['date_devis'];

class PDF extends PDF_MySQL_Table
{
function Header()
{
    $date_devis = $_GET['date_devis'];
    
	// Titre
	$this->SetFont('Arial','',18);
	$this->Cell(0,6,'Cosmos Quincaillerie',0,1,'C');
	$this->Ln(10);
    
    //Tampons
    $this->SetFont('Arial','',10);
    $this->Cell(0,6,'Cosmos Quincaillerie',0,1);
    $this->Cell(0,6,'situe a Abobo gendarmerie',0,1);
    $this->Cell(0,6,'en face la Banque Atlantique',0,1);
    $this->Cell(0,6,'tel: 55 25 12 01 / 55 68 19 77',0,1);
    $this->Ln(10);
    //date du devis
    $this->Cell(0,6,'Date: '.$date_devis,0,1,'R');
    $this->Ln(10);
    //numero Devis
    $this->Cell(90,6,'Devis N : ....',0,1,'R');
    $this->Ln(10);
	// Imprime l'en-tête du tableau si nécessaire
	parent::Header();
}
   function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-25);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Text color in gray
    $this->SetTextColor(128);
    $this->Cell(0,10,'Merci de nous faire Confiance',0,1,'C');
    $this->Cell(0,5,'A Bientot !!!',0,0,'C');
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'R');
}
}

// Connexion à la base
$link = mysqli_connect('localhost','root','','application_gestion');
$pdf = new PDF();
$pdf->AddPage();

 //client
    $sql_client = $bdd->query("SELECT nom_client, prenom_client FROM devis WHERE tel_client= '$id_client' AND date_devis= '$date_devis' " );
    $lire_client = $sql_client->fetch();
    $pdf->Cell(0,6,'Mr/Mme: '.$lire_client['nom_client'].$lire_client['prenom_client'],0,1);
    $pdf->Ln(3);

// Premier tableau : imprime toutes les colonnes de la requête
$pdf->AddCol('article_devis',100,'Designation');
$pdf->AddCol('prix_unitaire',40,'Prix unitaire','R');
$pdf->AddCol('quantite',20,'quantite','C');
$pdf->AddCol('total',40,'Total','R');
$pdf->Table($link,"select article_devis, prix_unitaire, quantite,total from devis where date_devis='$date_devis' and tel_client='$id_client' order by article_devis");

//le Total General
$sql = $bdd->query("SELECT SUM(total) as tot_gen FROM devis WHERE tel_client= '$id_client' AND date_devis= '$date_devis' " );

//affichage du total General 
$lire = $sql->fetch();
$pdf->SetFont('Arial','B',18);
$pdf->Cell(0,10,"Total General = ".$lire['tot_gen'].'F cfa',1,0,'R');


$pdf->Output("OfficeForm.pdf","F");

echo "<script>
    alert('chargement de l\'aperçu du devis')</script>
    <meta http-equiv=\"refresh\" content=\"0;URL=imprimer_facture.php\">";
?>
