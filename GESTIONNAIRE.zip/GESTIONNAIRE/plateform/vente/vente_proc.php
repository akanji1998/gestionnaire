<!--Enregistrement des ACHATS-->
<?php


require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';

    //recuperation des info de l'achat
    $id_client = $_POST['client'];
    $quantite = $_POST['quantite'];
    $id_article = $_POST['vente'];
    $date_achat = $_POST['date_achat'];
   
   
   

foreach($_POST['quantite'] as $quantite ){

  if(!empty($quantite) and $quantite>0){
      
      
     
        if(isset($_POST['vente'])){
           
           
            foreach($_POST['vente'] as $id_article) {
                
                
              
                //recuperation des article concernés par l'achat
                $prendre = $bdd->query("SELECT * FROM article WHERE id_article = '$id_article' ");
                $lire = $prendre->fetch();
                
                //quantite de l'article en stock
                $quantite_ini = $lire['quantite'];
                
                
                //quantite de l'article restant après achat
                $quantite_rest = $quantite_ini - $quantite;
                
                
                //mise à jours de l'article dans le stock
                if($quantite_rest>=0){
                        $update = $bdd->query("UPDATE article SET quantite= '$quantite_rest' WHERE id_article = '$id_article' ");

                    //recuperation des articles
                    $designation = $lire['designation'];
                    $prix_unitaire = $lire['prix_unitaire'];
                    $total = $lire['prix_unitaire']*$quantite;




                    //recuperation des informtions du client
                    $prendre_client = $bdd->query("SELECT * FROM client WHERE numero_client = '$id_client' ");
                    $lire_client = $prendre_client->fetch();

                    if(isset($id_client)){

                        $tel_client = $id_client;
                        $nom_client = $lire_client['nom'];
                        $prenom_client = $lire_client['prenom'];

                        //enregistrement de l'achat dans la table ACHAT
                        $inserer_achat = $bdd->query("INSERT INTO achat (nom_client,prenom_client,tel_client,article,prix_unitaire,quantite,total,mode_payement,date_achat) VALUES ('$nom_client', '$prenom_client', '$tel_client', '$designation', '$prix_unitaire', '$quantite', '$total','non paye','$date_achat') ");

                        if($inserer_achat){
                            /*echo "<script>
                            alert('Articles ajoutés"." "."avec succès')</script>
                            <meta http-equiv=\"refresh\" content=\"0;URL=vente.php\">";*/
                            
                            header('Location: vente.php');
                        }


                    } else 
                    echo "<script>
                    alert('veuillez selectionner "." "."un client')</script>
                    <meta http-equiv=\"refresh\" content=\"0;URL=vente.php\">";
                    
                } else
                echo "<script>
                    alert('les articles ".$lire['designation']." "."ne suffissent pas')</script>
                    <meta http-equiv=\"refresh\" content=\"0;URL=vente.php\">";
             
            }
            
        }else
        echo "<script>
        alert('veuillez selectionner "." "."au moins un articles')</script>
        <meta http-equiv=\"refresh\" content=\"0;URL=vente.php\">";
     
      
            
    } else
    echo "<script>
    alert('veuillez entrer "." "."la quantite des articles')</script>
    <meta http-equiv=\"refresh\" content=\"0;URL=vente.php\">";
    
} 


?>