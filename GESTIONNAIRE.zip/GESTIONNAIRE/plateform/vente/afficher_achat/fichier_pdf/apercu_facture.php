<?php
    $file = "C:/wamp64/www/GESTIONNAIRE/plateform/vente/afficher_achat/fichier_pdf/OfficeForm.pdf";
 
    header('content-type: application/pdf');
 
    //header('content-disposition: inline;filename"'.$file.'"');
    
    //header('content-transfer-encoding: binary');
    
    //header('Accept-Range: bytes');
    header('Content-length:'.filesize($file));
    readfile($file);
?>