<!--Affichage de l'achat-->

<?php
session_start();

require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';


//prendre client dans la BDD
$prendre_client = $bdd->query("SELECT * FROM client");

?>
<html>
    <head>
        <meta charset="utf-8">
        <title>Cosmos Quincaillerie - Panier d'achat</title>
         <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <!--Style css-->
        <link rel="stylesheet" href="afficher_achat.css" type="text/css">
        <style>
            /*LOGO*/
            .log {
                font-size: 30px;
                text-decoration: none;
                color: #fff;
               padding-left: 15px;
                position: relative;
                bottom: 10px;
            }
            .log span {
                color: #f4c613;
                font-size: 20px;
                position: relative;
                top: 17px;
                right: 70px;
            }
            .log:hover{
                text-decoration: none;
                color: #fff;
            }
            .admin h6 {
                color: #fff;
                margin: 0;
                margin-top: 10px;
            }
            .admin a {
                padding: 0;
                color: blue;
            }
            
            
            
        </style>
    </head>
    
    <body>
        
        <!--HEARDER ET NAVIGATION-->
        <div class="bg-dark fixed-top">
            <div class="container-fluid">
                <div class="row">            
                    <nav class="col navbar navbar-expand  bg-dark navbar-dark ">
                       
                        <a class="log navbar-brand" href="../vente.php">
                            Cosmos <span>Quincaillerie</span>
                        </a>

                        <ul class="navbar-nav">
                            <li class="nav-item active">
                                <a class="nav-link" href="../vente.php">Acceuil</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../client/affichage_client/affiche_client.php">Mes clients</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../enregistrement_article/affichage_articles/afficher_article.php">Mes articles</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../stock/affiche_stock.php">Mon stock</a>
                            </li>
                        </ul>
                        
                    </nav>
                    <div class="admin col-4 text-right">
                        <h6><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></h6>
                        <a href="#" class="btn">Déconnexion</a>
                    </div> 
                </div>
                
            </div>
            <div class="container-fluid">
               <div class="row">
                    <nav class="col navbar navbar-expand  bg-light navbar-light ">
                       
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="../vente.php">Achat</a>
                            </li>
                            <li class="nav-item active bg-dark">
                                <a class="nav-link" href="afficher_achat.php">Mon panier</a>
                            </li>
                        </ul>
                        
                    </nav>
                </div>
            </div>
        </div>
        <!--<header>
            <div class="logo">
                <h1><em>Cosmos</em></h1>
                <h3>Quincaillerie</h3>
            </div>
            <div class="navigation">
                <h3>Administrateur:<span><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></span></h3>
                <nav>
                    <ul>
                        <li><a href="../vente.php">retour à l'achat</a></li>
                    </ul>
                </nav>
            </div>
        </header>-->
     
        <!--configuration d'affichage de l'achat-->
        <div id="parametre">
           <form action="afficher_achat.php" method="post">
               <label>Client:</label>
                <select name="client" required>
                  <!--affichage des client-->
                   <option></option>
                   <?php while($lire_client=$prendre_client->fetch()){?>
                   
                    <option value="<?php echo $lire_client['numero_client']; ?>" title="<?php echo $lire_client['nom'].' '.$lire_client['prenom']; ?>"> <?php echo $lire_client['numero_client']; ?> </option>
                    
                    <?php } ?>
                </select>
                <label>date de l'achat:</label>
                <input type="date" name="date_achat" required>
                <input type="submit" value="ok" class="btn">
            </form>
        </div>
        
        <?php
        if(isset($_POST['client']) and isset($_POST['date_achat'])){
            
            $id_client = $_POST['client'];
            $date_achat = $_POST['date_achat'];
            
            //selection des achats du client
            $prendre_article = $bdd->query("SELECT * FROM achat WHERE tel_client= '$id_client' AND date_achat= '$date_achat' AND mode_payement='non paye' ");
            
            //calcul du prix total de l'achat
            $gran_total = $bdd->query("SELECT SUM(total) as gran_total FROM achat WHERE tel_client= '$id_client' AND date_achat= '$date_achat' AND mode_payement='non paye' ");
            
            $lire_gran_total = $gran_total->fetch();
            
            //selection du client effectuant l'achat
            $client_de_achat = $bdd->query("SELECT * FROM client WHERE numero_client = '$id_client' ");
            $lire_client_de_achat = $client_de_achat->fetch();
            
        ?>


        <div id="info_devis">
          <!--AFFICHAGE DU nom du CLIENT-->
           <?php if($lire_client_de_achat['civilite'] == 'homme'){ ?>
           <h3>Client : Mr <?php echo $lire_client_de_achat['nom'].' '.$lire_client_de_achat['prenom']; ?></h3>
           <?php } else{ ?>
           <h3>Cliente : Mme <?php echo $lire_client_de_achat['nom'].' '.$lire_client_de_achat['prenom']; ?></h3>
           <?php } ?>

           <!--Date d'achat et statut de l'achat-->
           <h5>
                <!--date d'achat-->
             Achat du <?php echo $date_achat; ?>
               
                <!--statut de l'achat-->
              Statut : <?php
                  /*if($lire_article['mode_payement'] == 'non paye'){
                      echo 'non payé';
                  }else if($lire_article['mode_payement'] !== 'cash à la caisse'){
                            echo 'payé par '. $lire_article['mode_payement'];
                  }else {
                      echo $lire_article['mode_payement'];
                  }*/
               ?>

           </h5>

           <h2>Total général : <?php echo $lire_gran_total['gran_total']; ?></h2>
           <h5>methode de payement:</h5>
           <ul>
               <li><a href="payement.php?mode_payement=cash à la caisse&date_achat=<?php echo $date_achat; ?>&client=<?php echo $id_client;?>">Cash à La Caisse</a></li>
               
               <li><a href="payement.php?mode_payement=mobile money&date_achat=<?php echo $date_achat; ?>&client=<?php echo $id_client;?>">Mobile Money</a></li>
               
               <li><a href="payement.php?mode_payement=Banque&date_achat=<?php echo $date_achat; ?>&client=<?php echo $id_client;?>">Banque</a></li>
           </ul>
        </div>
     
        <div style="margin-left:70px">
            <table id="example" class="table table-striped table-bordered table-center" style="width:80%">
               <thead>
                    <tr class="titre">
                        <th>Désignation</th>
                        <th>Prix unitaire</th>
                        <th>Quantité</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <?php while($lire_article = $prendre_article->fetch()){ ?>
                <tbody>
                    <tr class="text">
                        <td><?php echo $lire_article['article'];?></td>
                        <td><?php echo $lire_article['prix_unitaire'];?></td>
                        <td><?php echo $lire_article['quantite'];?></td>
                        <td><?php echo $lire_article['total'];?></td>
                    </tr>
                </tbody>
                <?php } ?>
            </table>
        </div>
        
        <?php 
            
        }
        ?>
        
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
        
        <!--Data table-->
        <script src="../../../js/jquery-3.5.1.js"></script>
        <script src="../../../js/jquery.dataTables.min.js"></script>
        <script src="../../../js/dataTables.bootstrap4.min.js"></script>
        <script>
            $(document).ready(function(){
                $('#example').DataTable();
            });
            
        </script>
    </body>
</html>
