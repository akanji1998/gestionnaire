<?php

require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';

$id_client = $_GET['client'];
$mode_payement = $_GET['mode_payement'];
$date_achat = $_GET['date_achat'];

//update paiement
$update_payement = $bdd->prepare("UPDATE achat SET mode_payement=:mode_payement WHERE tel_client=:id_client AND date_achat=:date_achat");
$update_payement->execute(array(
    'mode_payement' => $mode_payement,
    'id_client' => $id_client,
    'date_achat' => $date_achat
));


//update nmbre achats du client
$prendre_client = $bdd->query("SELECT  nom, prenom, nombre_achat FROM client WHERE numero_client = '$id_client' ");
$lire_client = $prendre_client->fetch();

$nombre_achat_ini = $lire_client['nombre_achat'];
$nombre_achat_fin = $nombre_achat_ini + 1;

$update_nombre_achat = $bdd->query("UPDATE client SET nombre_achat='$nombre_achat_fin' WHERE numero_client ='$id_client' ");



if($update_payement){
   
    if($update_nombre_achat){
        
       
        header('Location: fichier_pdf/facture_achat.php?client='.$id_client.'&date_achat='.$date_achat);
   
    }
    
    
}

?>