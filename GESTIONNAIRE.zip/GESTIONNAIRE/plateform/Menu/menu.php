<?php
session_start();
//connexion à la base de donnee.2
require 'C:/wamp64/www/GESTIONNAIRE/base de donnee/BDD.php';

?>
  <html>
      <head>
          <meta charset="utf-8">
          <title>Menu d'opération</title>
          <link rel="stylesheet" href="menu.css" type="text/css">
      </head>
      <body>
         
         <header>
             
              <div class="logo">
                  <h1><em>Cosmos</em></h1>
                  <h3>Quincaillerie</h3>
              </div>

               <div class="navigation">
                  <h3>Administrateur:<span><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></span></h3>
                   <nav>
                        <ul>
                            <li><a href="../../index.php">se déconnecté</a></li>
                           
                        </ul>
                    </nav>
               </div>
         </header>
          
          <div id="conteneur">
              
              <div id="menu">
                 <h1>Menu d'opérations</h1>
                 
                 <!--Client-->
                 
                 <div class="operations img_client">
                     <div class="overlay"></div>
                     <div class="overlay_content">
                         <h2>Client</h2>
                         <ul>
                             <li><a href="../client/client.php">Ajouter un client</a></li>
                             <li><a href="../client/affichage_client/affiche_client.php">Voir mes clients</a></li>
                         </ul>
                         <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur qui vitae optio odit tenetur assumenda quis numquam non molestias inventore esse expedita commodi et, similique sapiente! Delectus vel tenetur, veniam?</p>
                     </div>
                        
                 </div>
                 
                 <!--Opération de Vente-->
                 <div class="operations img_vente">
                        <div class="overlay"></div>
                        <div class="overlay_content">
                             <h2>Vente</h2>
                             <ul>
                                 <li><a href="../vente/vente.php">Vendre</a></li>
                                 <li><a href="../devis/devis.php">Créer un Devis</a></li>
                             </ul>
                             <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur qui vitae optio odit tenetur assumenda quis numquam non molestias inventore esse expedita commodi et, similique sapiente! Delectus vel tenetur, veniam?</p>
                         </div>
                     
                 </div>
                 
                 <!--Opération Enregistrement d'article-->
                 <div class="operations img_article">
                        <div class="overlay"></div>
                        <div class="overlay_content">
                         <h2>Enregistrement d'articles</h2>
                         <ul>
                             <li><a href="../enregistrement_article/ajouter_article_.php">Ajouter un article</a></li>
                             <li><a href="../enregistrement_article/affichage_articles/afficher_article.php">Voir mes articles</a></li>
                         </ul>
                         <p>Lorem ipsum dolor sit amet, consectetur 
                         <br>adipisicing elit. Consequatur qui vitae optio odit tenetur assumenda quis numquam non molestias inventore esse expedita commodi et, similique sapiente! Delectus vel tenetur, veniam?</p>
                     </div>
                 </div>
                 
                 <!--Le stock-->
                    <div class="operations img_stock">
                        <div class="overlay"></div>
                        <div class="overlay_content">
                         <h2>Point du stock</h2>
                         <ul>
                             <li><a href="../stock/affiche_stock.php">Voir le stock</a></li> 
                         </ul>
                         <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequatur qui vitae optio odit tenetur assumenda quis numquam non molestias inventore esse expedita commodi et, similique sapiente! Delectus vel tenetur, veniam?</p>
                       </div>
                     
                    </div>     
                 
              </div>
          </div>
          
      </body>
  </html> 
   
   
   
   
   
   
   
   
   
   
    
