 <?php
session_start();
?>

<html>
    <head>
        <meta charset="utf-8">
        <title>Cosmos Quincaillerie - Clients</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <!--Style css-->
        <link rel="stylesheet" href="client.css" type="text/css">
        
        <style>
            /*LOGO*/
            .log {
                font-size: 30px;
                text-decoration: none;
                color: #fff;
               padding-left: 15px;
                position: relative;
                bottom: 10px;
            }
            .log span {
                color: #f4c613;
                font-size: 20px;
                position: relative;
                top: 17px;
                right: 70px;
            }
            .log:hover{
                text-decoration: none;
                color: #fff;
            }
            .admin h6 {
                color: #fff;
                margin: 0;
                margin-top: 10px;
            }
            .admin a {
                padding: 0;
                color: blue;
            }
            
        </style>
    </head>
    <body>
       
        <!--HEARDER ET NAVIGATION-->
        <div class="bg-dark fixed-top">
            <div class="container-fluid">
                <div class="row">            
                    <nav class="col navbar navbar-expand  bg-dark navbar-dark ">
                       
                        <a class="log navbar-brand" href="../vente/vente.php">
                            Cosmos <span>Quincaillerie</span>
                        </a>

                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="../vente/vente.php">Acceuil</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../client/affichage_client/affiche_client.php">Mes clients</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../enregistrement_article/affichage_articles/afficher_article.php">Mes articles</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../stock/affiche_stock.php">Mon stock</a>
                            </li>
                        </ul>
                        
                    </nav>
                    <div class="admin col-4 text-right">
                        <h6><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></h6>
                        <a href="#" class="btn">Déconnexion</a>
                    </div> 
                </div>
                
            </div>
            <div class="container-fluid">
               <div class="row">
                    <nav class="col navbar navbar-expand  bg-light navbar-light ">
                       
                        <ul class="navbar-nav">
                            <li class="nav-item active bg-dark">
                                <a class="nav-link" href="client.php">Nouveau client</a>
                            </li>
                            <li class="nav-item ">
                                <a class="nav-link" href="affichage_client/affiche_client.php">Clients enrégistrés</a>
                            </li>
                        </ul>
                        
                    </nav>
                </div>
            </div>
        </div>
        <!--<header>
          <div class="logo">
              <h1><em>Cosmos</em></h1>
              <h3>Quincaillerie</h3>
          </div>

           <div class="navigation">
              <h3>Administrateur:<span><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></span></h3>
               <nav>
                    <ul>
                        <li id="admin"><a href="..\Menu\menu.php">rétourner au menu</a></li>
                    </ul>
                </nav>
           </div>
        </header>-->
        
        <div id="conteneur">
            <div class="formulaire">
               <h1>Client</h1>
                <form method="post" action="inscris_client.php" enctype="multipart/form-data">
                   <!--<label for="photo">Photo de profil: </label><br>
                   <input type="file" name="photo"  size="50"><br>
                   <input type="hidden" name="taille_photo" value="250000">-->
                    <label for="nom">Nom :</label><br>
                    <input type="text" name="nom" required><br>

                    <label for="prenom">Prénom :</label><br>
                    <input type="text" name="prenom" required><br>

                    <label for="telephone">téléphone :</label><br>
                    <input type="tel" name="telephone" placeholder="+255 55 25 12 01" required><br>

                    <label>Civilité : </label>
                    <select name="civilite" required>
                        <option value="homme">homme</option>
                        <option value="femme">femme</option>
                    </select><br>

                    <input type="submit" name="submit" value="ajouter" class="btn">
                </form>
            </div>
        </div>
        
        
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    </body>
</html>
