<?php


//$photo = $_FILES['photo'];
$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
//$tel = $_POST['telephone'];
$civilite = $_POST['civilite'];



//connexion à la base de donnee.
require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';

//lire le numero des clients dans la base
$prendre_tel = $bdd->query("SELECT numero_client FROM client");

//verifions si le numero existe;
while($lire_tel = $prendre_tel->fetch()){
    
    if($_POST['telephone'] == $lire_tel['numero_client']){
        
        $identique = 'identique';
        
      
    }
    
}
//execution de la condition ci-dessus
if(isset($identique)){
    echo "<script>
                alert('désolé Mr/Mmm : ".$nom." " .$prenom." le numero existe déjà vous êtes donc client')</script>
                <meta http-equiv=\"refresh\" content=\"0;URL=client.php\">"; 
    
} else{
    
    
    $tel = $_POST['telephone'];
    

    $ajouter = $bdd->query("INSERT INTO client (numero_client,nom,prenom,civilite,nombre_achat) VALUES ('$tel','$nom','$prenom','$civilite',0) ");
        
        $prendre = $bdd->query("SELECT nom, prenom FROM client ORDER BY id DESC");
        $lire = $prendre->fetch();
        
        if($ajouter){
            //renvoi à la page client
           echo "<script>
                alert('Mr/Mmm : ".$lire['nom']." " .$lire['prenom']." a été ajouté avec succès')</script>
                <meta http-equiv=\"refresh\" content=\"0;URL=client.php\">"; 
        }
   
}

?>