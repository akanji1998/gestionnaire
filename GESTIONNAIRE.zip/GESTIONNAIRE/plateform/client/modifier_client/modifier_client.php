<?php
session_start();

//connection à la base de donnée
require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';

    //recuperation de matricule
if(isset($_GET['rang'])){
    $rang = $_GET['rang'];
}

//requete pour interroger la BD

$prendre = $bdd->query("SELECT numero_client,nom, prenom, civilite, nombre_achat FROM client WHERE id = '$rang' ");

$lire = $prendre->fetch();


?>
<html>
    <head>
        <meta charset="utf-8">
        <title>Cosmos Quincaillerie - clients</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <!--Style css-->
        <link rel="stylesheet" href="modifier_client.css" type="text/css">
        
         <style>
            /*LOGO*/
            .log {
                font-size: 30px;
                text-decoration: none;
                color: #fff;
               padding-left: 15px;
                position: relative;
                bottom: 10px;
            }
            .log span {
                color: #f4c613;
                font-size: 20px;
                position: relative;
                top: 17px;
                right: 70px;
            }
            .log:hover{
                text-decoration: none;
                color: #fff;
            }
            .admin h6 {
                color: #fff;
                margin: 0;
                margin-top: 10px;
            }
            .admin a {
                padding: 0;
                color: blue;
            }
            
        </style>
    </head>
    <body>
        
        <!--HEARDER ET NAVIGATION-->
        <div class="bg-dark fixed-top">
            <div class="container-fluid">
                <div class="row">            
                    <nav class="col navbar navbar-expand  bg-dark navbar-dark ">
                       
                        <a class="log navbar-brand" href="../../vente/vente.php">
                            Cosmos <span>Quincaillerie</span>
                        </a>

                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="../../vente/vente.php">Acceuil</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../client/affichage_client/affiche_client.php">Mes clients</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../enregistrement_article/affichage_articles/afficher_article.php">Mes articles</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../stock/affiche_stock.php">Mon stock</a>
                            </li>
                        </ul>
                        
                    </nav>
                    <div class="admin col-4 text-right">
                        <h6><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></h6>
                        <a href="#" class="btn">Déconnexion</a>
                    </div> 
                </div>
                
            </div>
            <div class="container-fluid">
               <div class="row">
                    <nav class="col navbar navbar-expand  bg-light navbar-light ">
                       
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="../affichage_client/affiche_client.php">Clients enrégistrés</a>
                            </li>
                            <li class="nav-item active bg-dark">
                                <a class="nav-link" href="#">Modifier le client</a>
                            </li>
                        </ul>
                        
                    </nav>
                </div>
            </div>
        </div>
        <!--<header>
         
          <div class="logo">
              <h1><em>Cosmos</em></h1>
              <h3>Quincaillerie</h3>
          </div>

           <div class="navigation">
              <h3>Administrateur:<span><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></span></h3>
               <nav>
                    <ul>
                        <li><a href="../../client/affichage_client/affiche_client.php">retour aux client</a></li>
                    </ul>
                </nav>
           </div>
         
        </header>-->
        
        <div id="conteneur">
          <div class="formulaire">
               <form method="post" action="changement_client.php?rang=<?php echo $rang;?>" >
                   <h1>Mise à jour des données du client</h1>
                    <p><em>N.B: remettez les données initiales au champs inchangés</em></p>

                    <label>contact: </label>
                    <input type="text"  name="numero_client"  value="<?php echo $lire['numero_client']; ?>"><br>

                    <label>nom: </label>
                    <input type="text"  name="nom"  value="<?php echo $lire['nom']; ?>"><br>

                    <label>prénom: </label>
                    <input type="text" name="prenom"  value="<?php echo $lire['prenom']; ?>"><br>

                    <label>civilité: </label>
                    <select name="civilite" required>
                        <option value="<?php echo $lire['civilite']; ?>"><?php echo $lire['civilite']; ?></option>
                        <option value="femme">femme</option>
                        <option value="homme">homme</option>
                    </select><br>

                    <label>nombre d'achat: </label>
                    <input type="number" name="nombre_achat"  value="<?php echo $lire['nombre_achat']; ?>" disabled class="nbr_achat"><br>
                    <input type="submit"  value="changer"  id="submit" class="btn">
                </form>
            </div>
        </div>
        
         <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    </body>
</html>








