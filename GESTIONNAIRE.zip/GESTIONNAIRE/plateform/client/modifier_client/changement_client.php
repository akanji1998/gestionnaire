<?php
    
    //connection à la base de donnée
     require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';
    
        //recuperation des mise à jour
    if(isset($_GET['rang'])){
        $rang = $_GET['rang'];
    }
    $numero_client = $_POST['numero_client'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $civilite = $_POST['civilite'];
    
    
    //prendre le numero du client à modifier
    $prendre = $bdd->query("SELECT numero_client FROM client WHERE id='$rang' ");
    $lire = $prendre->fetch();
    
    //lire le numero des clients dans la base de donnée
    $prendre_tel = $bdd->query("SELECT numero_client FROM client");

    //verifions si le numero est identique;
    while($lire_tel = $prendre_tel->fetch()){
        
        if($_POST['numero_client'] == $lire_tel['numero_client'] and $_POST['numero_client'] != $lire['numero_client']){
            
            $identique = 'identique';
            //$tel = $_POST['telephone'];
            
        }
        
    }
 
    if(isset($identique)){
        echo "<script>
                alert('désolé Mr/Mmm : ".$nom." " .$prenom." le contact entré appartient déjà à un client')</script>
                <meta http-equiv=\"refresh\" content=\"0;URL=../affichage_client/affiche_client.php\">"; 
         
    } else{
    
    //mise à jours des informations du client
    $update = $bdd->prepare('UPDATE client SET numero_client = :numero_client, nom = :nom, prenom = :prenom, civilite = :civilite WHERE id= :rang');

    $update->execute(array('numero_client' => $numero_client,
                           'nom' => $nom,
                          'prenom' => $prenom,
                          'civilite' => $civilite,
                          'rang' => $rang));

        if($update){
            echo "<script>
            alert('Mise à jour "." "."effectuée avec succès')</script>
            <meta http-equiv=\"refresh\" content=\"0;URL=../affichage_client/affiche_client.php\">";
        }
    }
?>