<?php
//administrateur
session_start();

?>

<html>
    <head>
        <meta charset="utf-8">
        <title>Cosmos Quincaillerie - Mes articles</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <!--Style css-->
        <link  rel="stylesheet" href="ajouter_article_.css" type="text/css">
        <style>
            /*LOGO*/
            .log {
                font-size: 30px;
                text-decoration: none;
                color: #fff;
               padding-left: 15px;
                position: relative;
                bottom: 10px;
            }
            .log span {
                color: #f4c613;
                font-size: 20px;
                position: relative;
                top: 17px;
                right: 70px;
            }
            .log:hover{
                text-decoration: none;
                color: #fff;
            }
            .admin h6 {
                color: #fff;
                margin: 0;
                margin-top: 10px;
            }
            .admin a {
                padding: 0;
                color: blue;
            }
            
        </style>
        
    </head>
    <body>
      
      <!--HEARDER ET NAVIGATION-->
        <div class="bg-dark fixed-top">
            <div class="container-fluid">
                <div class="row">            
                    <nav class="col navbar navbar-expand  bg-dark navbar-dark ">
                       
                        <a class="log navbar-brand" href="../vente/vente.php">
                            Cosmos <span>Quincaillerie</span>
                        </a>

                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="../vente/vente.php">Acceuil</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../client/affichage_client/affiche_client.php">Mes clients</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../enregistrement_article/affichage_articles/afficher_article.php">Mes articles</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../stock/affiche_stock.php">Mon stock</a>
                            </li>
                        </ul>
                        
                    </nav>
                    <div class="admin col-4 text-right">
                        <h6><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></h6>
                        <a href="#" class="btn">Déconnexion</a>
                    </div> 
                </div>
                
            </div>
            <div class="container-fluid">
               <div class="row">
                    <nav class="col navbar navbar-expand  bg-light navbar-light ">
                       
                        <ul class="navbar-nav">
                            <li class="nav-item active bg-dark">
                                <a class="nav-link" href="../affichage_articles/afficher_article.php">Nouvel article</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="affichage_articles/afficher_article.php">Articles enrégistrés</a>
                            </li>
                        </ul>
                        
                    </nav>
                </div>
            </div>
        </div>
      <!--<header>
          <div class="logo">
              <h1><em>Cosmos</em></h1>
              <h3>Quincaillerie</h3>
          </div>

           <div class="navigation">
              <h3>Administrateur:<span><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></span></h3>
               <nav>
                    <ul>
                        <li id="admin"><a href="..\Menu\menu.php">rétourner au menu</a></li>
                    </ul>
                </nav>
           </div>
        </header>-->
       
        <div id="conteneur">
           <div class="formulaire">
               <h1>Article</h1>
               <!--<form method="post" enctype="multipart/form-data">
                    <label>photo de l'article</label>
                   <input type="file" name="img_article" accept="image/jpeg">
                   <input type="submit" name="choisie" value="Ok" class="btn"> 
                   <div><img src="" width="100" height="100" alt="photo de l'article"></div>
                   
               </form>-->
               
                <form method="post" action="ajouter_article_proc.php" enctype="multipart/form-data">
                     <label>photo de l'article</label>
                   <input type="file" name="img_article" accept="image/jpeg">
                   <div><img src="" width="100" height="100" alt="photo de l'article"></div>
                   
                    <label>Identifiant de l'article :</label><br>
                    <input type="text" name="id_article" required><br>

                    <label>Désignation :</label><br>
                    <input type="text" name="designation" required><br>

                    <label>Catégories</label><br>
                    <select name="categorie">
                        <option value="electricite">Electricité</option>
                        <option value="plomberie">Plomberie</option>
                        <option value="sanitaire">Sanitaire</option>
                        <option value="carroterie">Carroterie</option>
                        <option value="peinture">Peinture</option>
                        <option value="autres">Autres</option>
                    </select><br>

                    <label>Sous catégories</label><br>
                    <select name="sous_categorie">
                        <option value="elec_interrupteur">interrupteur</option>
                        <option value="elec_fil">fil/câble</option>
                        <option value="sani_robinet">robinet</option>
                        <option value="sani_lavabo">lavabo</option>
                        <option value="carreau 20x30">carreau 20x30</option>
                        <option value="carreau 30x30">carreau 30x30</option>
                        <option value="peinture à eau">Peinture à Eau</option>
                        <option value="peinture à huile">Peinture à Huile</option>
                        <option value="autres">autres</option>
                    </select><br>

                    <label>Description</label><br>
                    <textarea name="description" rows="10" cols="20"></textarea><br>

                    <label>Prix unitaire :</label><br>
                    <input type="number" name="prix_unitaire" placeholder="prix" required><br>

                    <label>Quantité :</label><br>
                    <input type="number" name="quantite"  required><br>

                    <input type="submit" name="submit" value="Ajouter" class="btn">
                </form>
            </div>
        </div>
        
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    </body>
</html>



