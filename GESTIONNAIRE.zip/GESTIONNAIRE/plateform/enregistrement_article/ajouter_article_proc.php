<?php


$id = htmlspecialchars($_POST['id_article']);
$designation = htmlspecialchars($_POST['designation']);
$categorie = htmlspecialchars($_POST['categorie']);
$sous_categorie = htmlspecialchars($_POST['sous_categorie']);
$description = htmlentities($_POST['description'],ENT_QUOTE);
$prix_unitaire = htmlspecialchars($_POST['prix_unitaire']);
$quantite = htmlspecialchars($_POST['quantite']);
//ajout image de l'article
$img_article = $_FILES['img_article']['name'];

$upload = "photos/".$img_article;
move_uploaded_file($_FILES['img_article']['tmp_name'],$upload);


    //connexion à la base de donnee.
    require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';

    //lire les identifiant des articles dans la base
     $prendre_id_article = $bdd->query("SELECT * FROM article WHERE id_article = '$id'");
     $lire_article = $prendre_id_article->fetch();

    //verifions si l'id_article existe dans les données
    if($lire_article['id_article'] == $id){
        $libelle_article = $lire_article['designation'];
       echo "<script>
                    alert('votre requête ne peut aboutir car l\'article $libelle_article "." exist déjà dans l\'inventaire')</script>
                    <meta http-equiv=\"refresh\" content=\"0;URL=ajouter_article_.php\">"; 
    } else if($prix_unitaire <= 0 || $quantite <= 0){
        echo "<script>
                alert('veillez entrer"." "."un prix et une quantité positif')</script>
                <meta http-equiv=\"refresh\" content=\"0;URL= ajouter_article_.php\">";
    }else {
       
        //ajoute de l'article
            $ajouter = $bdd->query("INSERT INTO article (id_article, designation, categorie, sous_categorie, description, prix_unitaire,quantite,img_article) VALUES ('$id','$designation','$categorie','$sous_categorie','$description','$prix_unitaire', '$quantite', '$img_article') ");
        
        if($ajouter){
                //renvoi à la page d'ajoute d'article
               /*echo "<script>
                alert('article ajouté avec succès')</script>
                <meta http-equiv=\"refresh\" content=\"0;URL= ajouter_article_.php\">";*/
                echo 'ajouter';
            }

    }
    /*while($lire_id_article = $prendre_id_article->fetch()){
        
        if($_POST['id_article'] == $lire_id_article['id_article']){
            
            $identifiant = $_POST['id_article'];
            
            
        }
    }
    //execution de la condition ci-dessus
    if(isset($identifiant)){
        echo "<script>
                    alert('votre requête ne peut aboutir car l\'article ".$identifiant." " ." existe dans la liste des articles')</script>
                    <meta http-equiv=\"refresh\" content=\"0;URL=ajouter_article_.php\">"; 

    } else{
        //recuperation de l'identifiant
        $id_article = htmlspecialchars($_POST['id_article']);

        //verification si le PRIX et la QUANTITE sont positif
        if($prix_unitaire < 0 || $quantite <0){
            echo "<script>
                alert('veillez entrer"." "."un prix et une quantité positif')</script>
                <meta http-equiv=\"refresh\" content=\"0;URL= ajouter_article_.php\">";
        } else {

            //ajoute de l'article
            $ajouter = $bdd->query("INSERT INTO article (id_article, designation, categorie, sous_categorie, description, prix_unitaire,quantite) VALUES ('$id_article','$designation','$categorie','$sous_categorie','$description','$prix_unitaire', '$quantite') ");

            if($ajouter){
                //renvoi à la page d'ajoute d'article
               echo "<script>
                alert('article ajouté avec succès')</script>
                <meta http-equiv=\"refresh\" content=\"0;URL= ajouter_article_.php\">";
            }

        }
    }*/
 
?>


