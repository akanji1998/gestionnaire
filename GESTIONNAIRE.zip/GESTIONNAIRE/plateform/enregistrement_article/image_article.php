<?php
//require("C:/wamp64/www/GESTIONNAIRE/plateform/enregistrement_article/ajouter_article_.php");

if(isset($_POST['choisie'])){
echo 'cliquer';
} else{
    echo 'pas cliquer';
}

//$img_article = $_FILES['img_article']
?>