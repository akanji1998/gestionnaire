<!--Liste des articles-->
<?php

session_start();

//connexion à la base de donnee.
require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';

//selection des articles
$prendre = $bdd->query("SELECT id_article, designation, categorie, sous_categorie, description, prix_unitaire, quantite FROM article");


?>
<html>
    <head>
        <meta charset="utf-8">
        <title>Cosmos Quincaillerie - Mes articles</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <!--Style css-->
        <link rel="stylesheet" href="afficher_article.css" type="text/css">
        
        <style>
            /*LOGO*/
            .log {
                font-size: 30px;
                text-decoration: none;
                color: #fff;
               padding-left: 15px;
                position: relative;
                bottom: 10px;
            }
            .log span {
                color: #f4c613;
                font-size: 20px;
                position: relative;
                top: 17px;
                right: 70px;
            }
            .log:hover{
                text-decoration: none;
                color: #fff;
            }
            .admin h6 {
                color: #fff;
                margin: 0;
                margin-top: 10px;
            }
            .admin a {
                padding: 0;
                color: blue;
            }
            
        </style>
    </head>
    <body>
       
       <!--HEARDER ET NAVIGATION-->
        <div class="bg-dark fixed-top">
            <div class="container-fluid">
                <div class="row">            
                    <nav class="col navbar navbar-expand  bg-dark navbar-dark ">
                       
                        <a class="log navbar-brand" href="../../vente/vente.php">
                            Cosmos <span>Quincaillerie</span>
                        </a>

                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="../../vente/vente.php">Acceuil</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../client/affichage_client/affiche_client.php">Mes clients</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="../../enregistrement_article/affichage_articles/afficher_article.php">Mes articles</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="../../stock/affiche_stock.php">Mon stock</a>
                            </li>
                        </ul>
                        
                    </nav>
                    <div class="admin col-4 text-right">
                        <h6><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></h6>
                        <a href="#" class="btn">Déconnexion</a>
                    </div> 
                </div>
                
            </div>
            <div class="container-fluid">
               <div class="row">
                    <nav class="col navbar navbar-expand  bg-light navbar-light ">
                       
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="../ajouter_article_.php">Nouvel article</a>
                            </li>
                            <li class="nav-item active bg-dark">
                                <a class="nav-link" href="afficher_article.php">Articles enrégistrés</a>
                            </li>
                        </ul>
                        
                    </nav>
                </div>
            </div>
        </div>
       <!--<header>
             
              <div class="logo">
                  <h1><em>Cosmos</em></h1>
                  <h3>Quincaillerie</h3>
              </div>

               <div class="navigation">
                  <h3>Administrateur:<span><?php echo $_SESSION['nom_admin'] .' '.$_SESSION['prenom_admin']; ?></span></h3>
                   <nav>
                        <ul>
                            <li><a href="../../Menu/menu.php">retour au menu</a></li>
                           
                        </ul>
                    </nav>
               </div>
               
         </header>-->
       
        <div id="conteneur">
            
            <h1>Mes Articles</h1>
            
            
           <form action="../modifier_ article/supprimer_article.php" method="post" name="sdouane">
              
               <div class="suppresion">
                  <input type="submit"  value="supprimer" id="btn_supprime"><br>
                    <a href="javascript:cocheToute();">Tout Cocher</a>
                    <a href="javascript:decocheToute();" class="decoche">Tout d&eacute;cocher</a>
              </div>
               
                
                    <?php while($lire = $prendre->fetch()){?>
                   <div id="article">
                     <input type="checkbox" name="supprime[]"  value="<?php echo $lire['id_article'];?>">
                     <div class="photo"></div>
                     <div class="propriete">
                          <!--Affichage des donnée dans le tableau-->
                          <h3>Identifiant :<span><?php echo $lire['id_article'];?></span></h3>
                           <h3>Désignation :<span><?php echo $lire['designation'];?></span></h3>
                           <h3>Catégorie : <span><?php echo $lire['categorie'];?></span></h3>
                           <h3>Sous-catégorie : <span><?php echo $lire['sous_categorie'];?></span></h3>
                           <h3>Descripton :</h3>
                           
                           <div class="description">
                               <p><?php echo $lire['description'];?></p>
                           </div>
                           
                           <h3>Prix unitaire :<span><?php echo $lire['prix_unitaire'];?></span></h3>
                           <h3>Quantité :<span><?php echo $lire['quantite'];?></span></h3>
                           <div class="modifier">
                               <a href="../modifier_ article/modifier_article.php?identifiant=<?php echo $lire['id_article'];?>">Modifier</a> 
                           </div>
                       </div>
                   </div>
                   <?php }?>
                
            </form>
            
        </div>
              
      <!--mecanisme de coche-->
       <script>
           
            function cocheToute(){
                var taille = document.forms['sdouane'].elements.length;
                var element = null;
                for(i=0; i < taille; i++){
                    element = document.forms['sdouane'].elements[i];
                    if(element.type == "checkbox")
                        element.checked = true;
                }
            }
           
            function decocheToute(){
               var taille = document.forms['sdouane'].elements.length;
               var element = null;
               for(i=0; i < taille; i++){
                  element = document.forms['sdouane'].elements[i];
                  if(element.type == "checkbox")
                      element.checked =false;
               }
            }
           
        </script>
        
        
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    </body>
</html>
