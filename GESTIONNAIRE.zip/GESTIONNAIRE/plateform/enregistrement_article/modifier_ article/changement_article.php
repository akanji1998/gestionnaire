<?php


//connection à la base de donnée
 require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';

    //recuperation de l'identifiant
if(isset($_GET['identifiant'])){
    $id_article = $_GET['identifiant'];
}
$designation = htmlspecialchars($_POST['designation']);
$categorie = htmlspecialchars($_POST['categorie']);
$sous_categorie = htmlspecialchars($_POST['sous_categorie']);
$description = htmlspecialchars($_POST['description']);
$prix_unitaire = htmlspecialchars($_POST['prix_unitaire']);
$quantite = htmlspecialchars($_POST['quantite']);

//requete pour interroger la BD

$prendre = $bdd->query("SELECT * FROM article WHERE id_article='$id_article' ");

$lire = $prendre->fetch();

$update = $bdd->prepare('UPDATE article SET designation = :designation, categorie = :categorie, sous_categorie = :sous_categorie, description = :description, prix_unitaire = :prix_unitaire, quantite = :quantite WHERE id_article = :id_article');

$update->execute(array('designation' => $designation,
                       'categorie' => $categorie,
                      'sous_categorie' => $sous_categorie,
                      'description' => $description,
                      'prix_unitaire' => $prix_unitaire,
                       'quantite' => $quantite,
                      'id_article' => $id_article));

    if($update){
        echo "<script>
        alert('Mise à jour "." "."effectuée avec succès')</script>
        <meta http-equiv=\"refresh\" content=\"0;URL=../affichage_articles/afficher_article.php\">";
    }
?>