<!--Suppression des articles-->
<?php



require 'C:\wamp64\www\GESTIONNAIRE\base de donnee\BDD.php';

if(isset($_POST['supprime'])){
    
    foreach($_POST['supprime'] as $value) {
        $supprimer = $bdd->prepare('DELETE FROM article WHERE id_article = :value ');

        $supprimer->execute(array('value' => $value));
        
    }
     if($supprimer){
            echo "<script>
            alert('suppression(s) "." "."effectuée(s) avec succès')</script>
            <meta http-equiv=\"refresh\" content=\"0;URL=../affichage_articles/afficher_article.php\">";
        }
    
} else
    header('Location: ../affichage_articles/afficher_article.php');

?>