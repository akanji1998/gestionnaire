<!DOCTYPE html>
<html>
    <head>
       <meta charset="utf-8">
        <title>Cosmos Quincaillerie - Administrateur</title>       
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <!--STYLE CSS DE LA PAGE-->
        <link rel="stylesheet" href="inscri_admi.css" type="text/css">
        <style>
            /*LOGO*/
            .log {
                font-size: 30px;
                text-decoration: none;
                color: #fff;
               padding-left: 15px;
               
            }
            .log span {
                color: #f4c613;
                font-size: 20px;
                position: relative;
                top: 17px;
                right: 70px;
            }
            .log:hover{
                text-decoration: none;
                color: #fff;
            }
            
        </style>
        
    </head>
    <body>
       
       <!--HEARDER ET NAVIGATION-->
        <div class="bg-dark">
            <div class="container-fluid">
                <div class="row">            
                    <nav class="col navbar  bg-dark navbar-dark">
                        <a class=" log" href="inscri_admi.php">
                            Cosmos <span>Quincaillerie</span>
                        </a>
                        
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a class="nav-link" href="../index.php">Login</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="inscri_admi.php">Administrateur</a>
                            </li>
                        </ul>
                       
                    </nav>
                </div>
            </div>
        </div>
        
       <!--<header>
          <div class="logo">
              <h1><em>Cosmos</em></h1>
              <h3>Quincaillerie</h3>
          </div>

           <div class="navigation">
               <nav>
                    <ul>
                        <li><a href="..\index.php">login</a></li>
                        <li id="admin"><a href="inscri_admi.php" >être administrateur</a></li>
                    </ul>
                </nav>
           </div>
        </header>-->
       
        <div id="conteneur">
            <div class="formulaire">
               <h1>administrateur</h1>
                <form method="post" action="inscri_admin_proc.php">
                    <label for="nom">Votre Nom :</label><br>
                    <input type="text" name="nom" required><br>

                    <label for="prenom">Votre Prénom :</label><br>
                    <input type="text" name="prenom" required><br>

                    <label for="telephone">téléphone :</label><br>
                    <input type="tel" name="telephone" placeholder="+255 55 25 12 01" required><br>

                    <label for="nom_utilisateur">créez un nom d'utilisateur :</label><br>
                    <input type="text" name="nom_utilisateur" placeholder="@abiola.cosmos" required><br>

                    <label for="password">créez un mot de pass :</label><br>
                    <input type="password" name="password" min="8" max="12" required><br>

                    <label for="password">Vérification :</label><br>
                    <input type="password" name="password-veri" min="8" max="12" required><br>
                    <input type="submit" name="submit" value="je m'enregistre" class="btn">
                </form>
            </div>
        </div>
        
        
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    </body>
</html>



