<?php

$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$telephone = $_POST['telephone'];
$nom_utili = $_POST['nom_utilisateur'];
$password = $_POST['password'];
$motdepass_veri = $_POST['password-veri'];

if($motdepass_veri == $password){
    
    $passwordcryp = password_hash($password,PASSWORD_BCRYPT);
    
        require('..\base de donnee\BDD.php');


    $ajout_admi = $bdd->query("INSERT INTO administrateur (nom, prenom, contact, nom_utilisateur, mot_de_passe) VALUES ('$nom','$prenom','$telephone','$nom_utili','$passwordcryp')");

    $prendre = $bdd->query("SELECT * FROM administrateur");


    if($ajout_admi){

        $lire = $prendre->fetch();

         echo "<script>
            alert('félicitation ".$nom." " .$prenom." vous êtes maintenant administrateur')</script>
            <meta http-equiv=\"refresh\" content=\"0;URL=Login\..\index.php\">";   
    }
    
  
}else{
    echo "<script>
        alert(' la vérification est incorrect "." " ." entrez un mot de passe identique')</script>
        <meta http-equiv=\"refresh\" content=\"0;URL=inscri_admi.php\">";   
}


//if(preg_match("#^+255 ([0-9 ]){4}$#"))

//connexion à la base de donnee.

?>
