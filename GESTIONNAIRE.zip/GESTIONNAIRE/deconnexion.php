<?php
session_start();
$nom = $_SESSION["nom_admin"];
$prenom = $_SESSION["prenom_admin"];

$deco = "<script>"."alert('Mr $nom"." "."$prenom"." vous serez déconnecté')"."</script>";

echo $deco;
if(!$deco)
        echo "au revoir";
else
    echo "bye bye";
?>
   
<script>
    
   var out = confirm('votre requête de déconnexion est en cours de traitement...')
    if(out == false){
        alert('merci de rester avec moi');
    }else {
        alert('déconnexion effectuée avec succès');
    }
</script>
   