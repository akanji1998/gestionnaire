<html>
    <head>
        <meta charset="utf-8">
        <title>Cosmos Quincaillerie - Login</title>       
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <!--STYLE CSS DE LA PAGE-->
        
        <!-- <style>
            /*LOGO*/
            .logo {
                font-size: 30px;
                text-decoration: none;
                color: #fff;
               padding-left: 15px;
            }
            .logo span {
                color: #f4c613;
                font-size: 20px;
                position: relative;
                top: 17px;
                right: 70px;
            }
            .logo:hover{
                text-decoration: none;
                color: #fff;
            }

            /*conteneur*/
            #conteneur {
                display: table;
                width: 100%;
                height: 85%;
            }
            #forme {
                display: table-cell;
                vertical-align: middle;
            }
            
            form {
                padding: 25px;
            }
            form h1 {
                margin-bottom: 30px;
                font-weight: 400;
            }
            form label {
                font-size: 20px;
            }
            form input.btn {
                background-color: #f4c613;
                border: #f4c613;
                margin-top: 15px;
            }
            
            
        </style> -->
        <style>
            /*COSMOS QUINCAILLERIE*/
            header div.logo h1{
                color: #f4c613;
                display: inline-block;
                margin: 0;
                text-transform: capitalize;
                font-size: 25px;
                font-weight:200;
                letter-spacing: 2px;
                animation-name: colorone;
                animation-duration: 10s;
                animation-delay: 2s;
                animation-iteration-count: infinite;
                animation-timing-function: ease-in-out;
                padding-top: 10px;
                padding-left: 10px;
            }
        </style>
       
    </head>
    
    <body>
        <!--HEARDER ET NAVIGATION-->
        <div class="bg-dark">
            <div class="container-fluid">
                <div class="row">            
                    <nav class="col navbar  bg-dark navbar-dark">
                        <a class="logo" href="index.php">
                            Cosmos <span>Quincaillerie</span>
                        </a>
                        
                       
                        <ul class="navbar-nav">
                            <li class="nav-item active">
                                <a class="nav-link" href="index.php">Login</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="Admin/inscri_admi.php">Administrateur</a>
                            </li>
                        </ul>
                       
                    </nav>
                </div>
            </div>
        </div>
        
        <!--FORMULAIRE DE LOGIN-->
        <section id="login">
            <div class="container-fluid">
               <div id="conteneur">
                   <div id="forme">
                  
                        <div class="row">
                           <div class="col-md-4"></div>
                           
                            <div class="col-md-4 bg-primary">
                                <form method="post" action="login.php">
                                    <h1>Login</h1>
                                    <div class="form-group">
                                        <label for="nom_utilisateur">Nom d'utilisateur</label>
                                        <input type="text" class="form-control" id="nom_utilisateur" name="nom_utilisateur" required>
                                        <div class="invalid-feedback">veuillez entrer votre nom d'utilisateur</div>
                                    </div>
                                    <div class="form-group">
                                        <label for="nom_utilisateur">Mot de passe</label>
                                        <input type="password" class="form-control" id="nom_utilisateur" name="password" required>
                                    </div>
                                    <input type="submit" class="btn btn-primary" value="Se Connecter" >           
                                </form>
                            </div>
                            
                            <div class="col-md-4"></div>
                        </div>
                    
                    </div>
                </div>
            </div>
        </section>
        
        
        
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
        
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
        
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    </body>
</html>